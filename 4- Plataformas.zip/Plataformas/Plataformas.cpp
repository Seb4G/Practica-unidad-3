#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Texture textura;
Texture textura2;
Texture textura3;
Texture textura4;
Texture textura5;
Texture textura6;
Texture textura7;
Texture textura8;
Sprite sprite;
Sprite sprite2;
Sprite sprite3;
Sprite sprite4;
Sprite sprite5;
Sprite sprite6;
Sprite sprite7;
Sprite sprite8;

int main() {

    textura.loadFromFile("plataforma.jpg");
    sprite.setTexture(textura);
    float ancho = 100.0f / 450.0f;
    float alto = 100.0f / 290.0f;
    sprite.setScale(ancho, alto);
    sprite.setPosition(0, 515);

    textura2.loadFromFile("plataforma.jpg");
    sprite2.setTexture(textura2);
    float ancho2 = 100.0f / 450.0f;
    float alto2 = 100.0f / 180.0f;
    sprite2.setScale(ancho2, alto2);
    sprite2.setPosition(70, 460);

    textura3.loadFromFile("plataforma.jpg");
    sprite3.setTexture(textura3);
    float ancho3 = 100.0f / 450.0f;
    float alto3 = 100.0f / 120.0f;
    sprite3.setScale(ancho3, alto3);
    sprite3.setPosition(140, 390);

    textura4.loadFromFile("plataforma.jpg");
    sprite4.setTexture(textura4);
    float ancho4 = 100.0f / 450.0f;
    float alto4 = 100.0f / 90.0f;
    sprite4.setScale(ancho4, alto4);
    sprite4.setPosition(210, 320);

    textura5.loadFromFile("plataforma.jpg");
    sprite5.setTexture(textura5);
    float ancho5 = 100.0f / 450.0f;
    float alto5 = 100.0f / 70.0f;
    sprite5.setScale(ancho5, alto5);
    sprite5.setPosition(280, 235);

    textura6.loadFromFile("plataforma.jpg");
    sprite6.setTexture(textura6);
    float ancho6 = 100.0f / 450.0f;
    float alto6 = 100.0f / 55.0f;
    sprite6.setScale(ancho6, alto6);
    sprite6.setPosition(350, 135);

    textura7.loadFromFile("plataforma.jpg");
    sprite7.setTexture(textura7);
    float ancho7 = 100.0f / 450.0f;
    float alto7 = 100.0f / 50.0f;
    sprite7.setScale(ancho7, alto7);
    sprite7.setPosition(420, 90);

    textura8.loadFromFile("plataforma.jpg");
    sprite8.setTexture(textura8);
    float ancho8 = 100.0f / 85.0f;
    float alto8 = 100.0f / 530.0f;
    sprite8.setScale(ancho8, alto8);
    sprite8.setPosition(490, 90);

    RenderWindow Ventana(VideoMode(800, 600), "Plataformas");

    while (Ventana.isOpen()) {
        Ventana.clear();

        Ventana.draw(sprite);
        Ventana.draw(sprite2);
        Ventana.draw(sprite3);
        Ventana.draw(sprite4);
        Ventana.draw(sprite5);
        Ventana.draw(sprite6);
        Ventana.draw(sprite7);
        Ventana.draw(sprite8);

        Ventana.display();
    }
    return 0;
}