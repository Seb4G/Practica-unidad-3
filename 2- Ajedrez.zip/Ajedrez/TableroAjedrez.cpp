#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int main() {

    Texture texturaW;
    Texture texturaB;
    Sprite Sprite;

    texturaW.loadFromFile("chessw.png");
    texturaB.loadFromFile("chessb.png");

    RenderWindow Ventana(VideoMode(800, 800), "Tablero de ajedrez");

    while (Ventana.isOpen()) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if ((i + j) % 2 == 0) {
                    Sprite.setTexture(texturaW);
                }
                else {
                    Sprite.setTexture(texturaB);
                }
                Sprite.setPosition(i * 100, j * 100);
                Ventana.draw(Sprite);
            }
        }
        Ventana.display();
    }
    return 0;
}
